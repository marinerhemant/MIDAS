#!/bin/bash

source ${HOME}/.MIDAS/pathsNF

${BINFOLDER}/FitOrientation $1 $2 $3
