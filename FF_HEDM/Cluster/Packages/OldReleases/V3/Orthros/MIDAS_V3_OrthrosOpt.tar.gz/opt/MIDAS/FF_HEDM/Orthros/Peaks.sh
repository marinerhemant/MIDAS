#!/bin/bash
source ${HOME}/.MIDAS/paths
${BINFOLDER}/PeaksFittingPerFile $1 $2 $3
