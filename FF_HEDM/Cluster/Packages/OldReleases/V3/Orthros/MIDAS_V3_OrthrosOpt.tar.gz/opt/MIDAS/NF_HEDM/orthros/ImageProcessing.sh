#!/bin/bash

source ${HOME}/.MIDAS/pathsNF

${BINFOLDER}/ImageProcessing $1 $2 $3
