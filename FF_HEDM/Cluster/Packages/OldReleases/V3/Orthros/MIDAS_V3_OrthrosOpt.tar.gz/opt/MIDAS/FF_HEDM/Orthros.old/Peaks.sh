#!/bin/bash

/clhome/TOMO1/PeaksAnalysisHemant/HEDM_V2/FF_HEDM/bin/PeaksFittingPerFile $1 $2 $3
