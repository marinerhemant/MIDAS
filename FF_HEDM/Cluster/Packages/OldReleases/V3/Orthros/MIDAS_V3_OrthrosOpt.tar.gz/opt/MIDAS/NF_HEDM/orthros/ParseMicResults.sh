for i in *.out; do
   tail -n 1 "$i"
done
