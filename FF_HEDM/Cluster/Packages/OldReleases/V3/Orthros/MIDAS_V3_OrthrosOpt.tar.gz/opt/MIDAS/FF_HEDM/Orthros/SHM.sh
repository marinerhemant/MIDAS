#!/bin/bash -eu
source ${HOME}/.MIDAS/paths
${BINFOLDER}/SaveBinData
