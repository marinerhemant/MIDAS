#!/bin/bash
source ${HOME}/.MIDAS/paths
${BINFOLDER}/MergeOverlappingPeaks $1 $2
