app echo (string s) { 
   echo s; 
}

echo("hi");
